# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pharmacy']

package_data = \
{'': ['*']}

install_requires = \
['python-dateutil>=2.5.3',
 'requests-toolbelt>=0.10.1',
 'setuptools>=21.0.0',
 'urllib3>=1.26.15']

setup_kwargs = {
    'name': 'pharmacy',
    'version': '0.2.1',
    'description': 'The pharmacy module is a set of utilities for use with hospital and retail pharmacy data.',
    'long_description': 'None',
    'author': 'Danny Limoges, PharmD',
    'author_email': 'pharmacydataland@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
