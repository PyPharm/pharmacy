# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pharmacy']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pharmacy',
    'version': '0.1.0',
    'description': "The 'pharmacy' module is a set of utilities for use with hospital and retail pharmacy data.",
    'long_description': '.. pharmacy documentation master file, created by\n   sphinx-quickstart on Sat Apr 30 23:42:56 2022.\n\n.. _source: https://docutils.sourceforge.io/docs/ref/rst/restructuredtext.html\n.. https://stackoverflow.com/questions/59903051/sphinxs-autodocs-automodule-having-apparently-no-effect\n\n.. meta::\n   :description: pharmacy Module Documentation\n   :keywords: python, pharmacy, sql, medicine, medical, apha, ashp, ichp, pharmacist, technician, doctor, hospital\n\nWelcome to the *pharmacy* module documentation.\n=====================================\n\n.. toctree::\n   :maxdepth: 2\n   :caption: :\n\n   ndc\n   standardcolumnnames\n\nThe *pharmacy* module is intended to be a selection of utilities, classes and APIs intended to make pharmacy and healthcare data analytics easier.\nQuickly compare prices, pull live data about drugs from OpenFDA and perform complex fuzzy matches with little code.\n\n-----------------------------------\nGeneral Pattern - Read First\n-----------------------------------\n..  comment\n\n#. Load source data into pandas DataFrames\n\n#. Rename columns as the appropriate :doc:`Standard Column Names <standardcolumnnames>`.\n\n   a. Most project time is spent here but be **patient** and **accurate**.\n      Ensure that source columns match the definitions in :doc:`Standard Column Names <standardcolumnnames>`.\n   b. Columns do not need to be renamed if they will not be part of the operations that\n      the user wants to perform.\n\n.. hint:: It is important to jump in and start working with real data.\n          Avoid the urge to standardize every single column title.\n          Have some fun with the data!\n\n\n\n\n\n\n\nIndices and tables\n==================\n* :ref:`genindex`\n* :ref:`modindex`\n* :ref:`search`\n',
    'author': 'Danny Limoges, PharmD',
    'author_email': 'pharmacydataland@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
